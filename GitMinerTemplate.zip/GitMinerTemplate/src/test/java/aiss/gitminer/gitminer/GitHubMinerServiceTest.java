package aiss.gitminer.gitminer;

import aiss.gitminer.model.Commit;
import aiss.gitminer.model.Issue;
import aiss.gitminer.model.Project;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class GitHubMinerServiceTest {

    @Autowired
    GitHubMinerService GitHubMinerService;

    @Test
    @DisplayName("Get Project from GitHub")
    void getProject() {
        String owner = "spring-projects";
        String repo = "spring-framework";
        Project project = GitHubMinerService.getProject(owner, repo);
        assertNotNull(project, "The project is null!");
        assertEquals("spring-framework", project.getProjectName(), "The project name does not match!");
        System.out.println(project);
    }

    @Test
    @DisplayName("Get Commits from GitHub")
    void getCommits() {
        String owner = "spring-projects";
        String repo = "spring-framework";
        List<Commit> commits = GitHubMinerService.getCommits(owner, repo, "2");
        assertFalse(commits.isEmpty(), "The list of commits is empty!");
        System.out.println(commits);
    }

    @Test
    @DisplayName("Get Issues from GitHub")
    void getIssues() {
        String owner = "spring-projects";
        String repo = "spring-framework";
        List<Issue> issues = GitHubMinerService.getIssues(owner, repo, "20");
        assertFalse(issues.isEmpty(), "The list of issues is empty!");
        System.out.println(issues);
    }
}
