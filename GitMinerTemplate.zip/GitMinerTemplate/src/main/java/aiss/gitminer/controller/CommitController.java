package aiss.gitminer.controller;

import aiss.gitminer.model.Commit;
import aiss.gitminer.service.CommitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/gitminer/commits")
public class CommitController {

    @Autowired
    private CommitService commitService;

    // GET /gitminer/commits
    @GetMapping
    public ResponseEntity<List<Commit>> getAllCommits() {
        List<Commit> commits = commitService.getAllCommits();
        return ResponseEntity.ok(commits);
    }

    // GET /gitminer/commits/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Commit> getCommitById(@PathVariable String id) {
        Commit commit = commitService.getCommitById(id);
        return commit != null ? ResponseEntity.ok(commit) : ResponseEntity.notFound().build();
    }

    // PUT /gitminer/commits/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Commit> updateCommit(@PathVariable String id, @RequestBody Commit updatedCommit) {
        Commit existingCommit = commitService.getCommitById(id);
        if (existingCommit == null) {
            return ResponseEntity.notFound().build();
        }

        updatedCommit.setId(id);
        Commit savedCommit = commitService.updateCommit(updatedCommit);
        return ResponseEntity.ok(savedCommit);
    }

    // DELETE /gitminer/commits/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Commit> deleteCommit(@PathVariable String id) {
        Commit commit = commitService.getCommitById(id);
        if (commit == null) {
            return ResponseEntity.notFound().build();
        }
        commitService.deleteCommit(id);
        return ResponseEntity.noContent().build();
    }
}
