package aiss.gitminer.service;

import aiss.gitminer.model.Commit;
import aiss.gitminer.repository.CommitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommitService {

    @Autowired
    private CommitRepository commitRepository;

    // Devuelve todos los commits
    public List<Commit> getAllCommits() {
        return commitRepository.findAll();
    }

    // Devuelve un commit por ID
    public Commit getCommitById(String id) {
        Optional<Commit> commit = commitRepository.findById(id);
        return commit.orElse(null);
    }

    // Guarda un commit nuevo
    public Commit saveCommit(Commit commit) {
        return commitRepository.save(commit);
    }

    // Elimina un commit
    public void deleteCommit(String id) {
        commitRepository.deleteById(id);
    }
}
