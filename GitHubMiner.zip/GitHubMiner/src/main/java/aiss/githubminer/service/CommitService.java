package aiss.githubminer.service;

import aiss.githubminer.authorizationService.AuthorizationService;
import aiss.githubminer.model.Commit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneOffset;

@Service
public class CommitService {

    @Autowired
    AuthorizationService authorizationService;

    @Value("${githubminer.baseUri}" + "repos/")
    private String baseUri;

    // Versión modificada: soporta paginación
    public List<Commit> getCommits(String owner, String repo, String sinceCommits, String maxPages) {
        List<Commit> allCommits = new ArrayList<>();
        String maxPagesClean = maxPages.trim();  // Elimina espacios y saltos de línea
        int pages = Integer.parseInt(maxPagesClean);

        ZonedDateTime dateTime = ZonedDateTime.now(ZoneOffset.UTC).minusDays(Integer.parseInt(sinceCommits));
        String since = dateTime.format(DateTimeFormatter.ISO_INSTANT);

        for (int i = 1; i <= pages; i++) {
            String uri = baseUri + owner + "/" + repo + "/commits?since=" + since + "&page=" + i + "&per_page=100";
            ResponseEntity<Commit[]> response = authorizationService.getWithToken(uri, Commit[].class);
            Commit[] commits = response.getBody();

            if (commits == null || commits.length == 0) {
                break;
            }

            allCommits.addAll(Arrays.asList(commits));

            // Opcional: si una página tiene menos de 100 elementos, ya no hay más
            if (commits.length < 100) {
                break;
            }
        }

        return allCommits;
    }

    public Commit getCommitBySha(String owner, String repo, String sha) {
        String uri = baseUri + owner + "/" + repo + "/commits/" + sha;
        ResponseEntity<Commit> response = authorizationService.getWithToken(uri, Commit.class);
        return response.getBody();
    }
}
