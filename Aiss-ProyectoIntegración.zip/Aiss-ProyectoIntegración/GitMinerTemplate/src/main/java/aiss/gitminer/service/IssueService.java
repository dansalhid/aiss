package aiss.gitminer.service;

import aiss.gitminer.model.Comment;
import aiss.gitminer.model.Issue;
import aiss.gitminer.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IssueService {

    @Autowired
    private IssueRepository issueRepository;

    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    public Issue getIssueById(String id) {
        return issueRepository.findById(id).orElse(null);
    }

    public List<Issue> getIssuesByState(String state) {
        return issueRepository.findByState(state);
    }

    public List<Comment> getCommentsFromIssue(String id) {
        Issue issue = issueRepository.findById(id).orElse(null);
        return issue != null ? issue.getComments() : null;
    }

    public Issue updateIssue(Issue issue) { return issueRepository.save(issue); }
}
