package aiss.gitminer.controller;

import aiss.gitminer.model.Project;
import aiss.gitminer.service.ProjectService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/gitminer/projects")
@Tag(name = "Proyectos", description = "Operaciones relacionadas con proyectos")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @Operation(
            summary = "Crear un nuevo proyecto",
            description = "Crea un nuevo proyecto y lo guarda en la base de datos"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Proyecto creado correctamente",
                    content = @Content(schema = @Schema(implementation = Project.class))),
            @ApiResponse(responseCode = "400", description = "Petición incorrecta")
    })
    @PostMapping
    public ResponseEntity<Project> createProject(@RequestBody Project project) {
        Project savedProject = projectService.createProject(project);
        return ResponseEntity.status(201).body(savedProject);
    }

    @Operation(
            summary = "Obtener todos los proyectos",
            description = "Devuelve una lista de todos los proyectos disponibles"
    )
    @ApiResponse(responseCode = "200", description = "Lista de proyectos",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Project.class))))
    @GetMapping
    public ResponseEntity<List<Project>> getAllProjects() {
        List<Project> projects = projectService.getAllProjects();
        return ResponseEntity.ok(projects);
    }

    @Operation(
            summary = "Obtener un proyecto por ID",
            description = "Busca y devuelve un proyecto según su ID"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Proyecto encontrado",
                    content = @Content(schema = @Schema(implementation = Project.class))),
            @ApiResponse(responseCode = "404", description = "Proyecto no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Project> getProjectById(@PathVariable String id) {
        Project project = projectService.getProjectById(id);
        return project != null ? ResponseEntity.ok(project) : ResponseEntity.notFound().build();
    }

    @Operation(
            summary = "Actualizar un proyecto existente",
            description = "Actualiza los datos de un proyecto existente identificado por su ID"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Proyecto actualizado",
                    content = @Content(schema = @Schema(implementation = Project.class))),
            @ApiResponse(responseCode = "404", description = "Proyecto no encontrado")
    })
    @PutMapping("/{id}")
    public ResponseEntity<Project> updateProject(@PathVariable String id, @RequestBody Project updatedProject) {
        Project existingProject = projectService.getProjectById(id);
        updatedProject.setId(id);
        Project savedProject = projectService.updateProject(updatedProject);
        return existingProject != null ? ResponseEntity.ok(savedProject) : ResponseEntity.notFound().build();
    }

    @Operation(
            summary = "Eliminar un proyecto",
            description = "Elimina un proyecto existente según su ID"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Proyecto eliminado"),
            @ApiResponse(responseCode = "404", description = "Proyecto no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Project> deleteProject(@PathVariable String id) {
        Project project = projectService.getProjectById(id);
        projectService.deleteProject(id);
        return project != null ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
