package aiss.bitbucketminer.service;

import aiss.bitbucketminer.authorizationService.AuthorizationService;
import aiss.bitbucketminer.model.Issue;
import aiss.bitbucketminer.model.IssueValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IssueService {

    @Autowired
    AuthorizationService authorizationService;

    @Value("${bitbucketminer.baseUri}")
    private String baseUri;

    public List<IssueValue> getIssues(String workspace, String repoSlug, int nIssues, int maxPages) {
        List<IssueValue> allIssues = new java.util.ArrayList<>();
        int perPage = Math.min(nIssues, 100);
        int page = 1;
        int collected = 0;

        while (page <= maxPages && collected < nIssues) {
            String uri = baseUri + workspace + "/" + repoSlug + "/issues?pagelen=" + perPage + "&page=" + page;
            ResponseEntity<Issue> response = authorizationService.getWithToken(uri, Issue.class);

            if (response.getBody() == null || response.getBody().getValues() == null || response.getBody().getValues().isEmpty()) {
                break;
            }

            List<IssueValue> pageIssues = response.getBody().getValues();
            for (IssueValue issue : pageIssues) {
                if (collected >= nIssues) break;
                allIssues.add(issue);
                collected++;
            }

            if (pageIssues.size() < perPage) break;

            page++;
        }

        return allIssues;
    }

    public IssueValue getIssueByNumber(String workspace, String repoSlug, String id) {
        String uri = baseUri + workspace + "/" + repoSlug + "/issues/" + id;
        ResponseEntity<IssueValue> response = authorizationService.getWithToken(uri, IssueValue.class);
        return response.getBody();
    }
}
