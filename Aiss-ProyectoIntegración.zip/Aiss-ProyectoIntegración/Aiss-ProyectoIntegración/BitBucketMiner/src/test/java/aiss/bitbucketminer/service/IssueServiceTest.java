package aiss.bitbucketminer.service;

import aiss.bitbucketminer.model.IssueValue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class IssueServiceTest {

    @Autowired
    private IssueService issueService;

    @Test
    @DisplayName("List of Issues with Pagination")
    void getIssues() {
        String workspace = "gentlero";
        String repoSlug = "bitbucket-api";
        int nIssues = 5;
        int maxPages = 2;
        List<IssueValue> issues = issueService.getIssues(workspace, repoSlug, nIssues, maxPages);
        assertNotNull(issues, "The list of issues is null!");
        assertFalse(issues.isEmpty(), "The list of issues is empty!");
        System.out.println("Issues: " + issues);
    }

    @Test
    @DisplayName("Get Issue by Id")
    void getIssueByNumber() {
        String workspace = "gentlero";
        String repoSlug = "bitbucket-api";
        String number = "87";
        IssueValue issue = issueService.getIssueByNumber(workspace, repoSlug, number);
        assertNotNull(issue, "The issue is null!");
        System.out.println("Issue: " + issue);
    }
}
