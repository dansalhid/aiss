package aiss.gitminer.service;

import aiss.gitminer.model.Project;
import aiss.gitminer.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    // Método para crear un proyecto
    public Project createProject(Project project) {
        return projectRepository.save(project);
    }

    // Método para obtener todos los proyectos
    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    // Método para obtener un proyecto por id
    public Project getProjectById(String id) { return projectRepository.findById(id).orElse(null); }

    // Método para actualizar un proyecto
    public Project updateProject(Project project) { return  projectRepository.save(project); }

    // Método para borrar un proyecto
    public void deleteProject(String id) { projectRepository.deleteById(id); }
}
