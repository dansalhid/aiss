Para el correcto funcionamiento de la aplicación, se requiere por parte del usuario la elaboración de variables de entorno en su propio dispositivo.

Tales variables deben ser:

BITBUCKET_USERNAME: {incluye el nombre del usuario en la plataforma bitbucket}
BITBUCKET_TOKEN: {incluye un token de autenticación del usuario para la plataforma bitbucket}
GITHUB_TOKEN: {incluye un token de autenticación del usuario para la plataforma github}

Dichos tokens han de tener permisos consecuentes con la petición o peticiones realizadas y es de vital importancia que sus nombres sean exactamente los indicados previamente.