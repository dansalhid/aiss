package aiss.bitbucketminer.service;

import aiss.bitbucketminer.model.CommitValue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class CommitServiceTest {

    @Autowired
    private CommitService commitService;

    @Test
    @DisplayName("List of Commit with Pagination")
    void getCommits() {
        String workspace = "gentlero";
        String repoSlug = "bitbucket-api";
        int nCommits = 5;
        int maxPages = 2;
        List<CommitValue> commits = commitService.getCommits(workspace, repoSlug, nCommits, maxPages);
        assertNotNull(commits, "The list of commits is null!");
        assertFalse(commits.isEmpty(), "The list of commits is empty!");
        System.out.println("Commits: " + commits);
    }

    @Test
    @DisplayName("Get Commit by Id")
    void getCommitId() {
        String workspace = "gentlero";
        String repoSlug = "bitbucket-api";
        String id = "67a0362b29f34c45251ce88c5851756fb30a65cc";
        CommitValue commit = commitService.getCommitId(workspace, repoSlug, id);
        assertNotNull(commit, "The commit is null!");
        System.out.println("Commit: " + commit);
    }
}
