package aiss.bitbucketminer.service;

import aiss.bitbucketminer.authorizationService.AuthorizationService;
import aiss.bitbucketminer.model.Commit;
import aiss.bitbucketminer.model.CommitValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CommitService {

    @Autowired
    AuthorizationService authorizationService;

    @Value("${bitbucketminer.baseUri}")
    private String baseUri;

    public List<CommitValue> getCommits(String workspace, String repoSlug, int nCommits, int maxPages) {
        List<CommitValue> allCommits = new java.util.ArrayList<>();
        int perPage = Math.min(nCommits, 100);
        int page = 1;
        int collected = 0;

        while (page <= maxPages && collected < nCommits) {
            String uri = baseUri + workspace + "/" + repoSlug + "/commits?pagelen=" + perPage + "&page=" + page;
            ResponseEntity<Commit> response = authorizationService.getWithToken(uri, Commit.class);

            if (response.getBody() == null || response.getBody().getValues() == null || response.getBody().getValues().isEmpty()) {
                break;
            }

            List<CommitValue> pageCommits = response.getBody().getValues();
            for (CommitValue commit : pageCommits) {
                if (collected >= nCommits) break;
                allCommits.add(commit);
                collected++;
            }

            if (pageCommits.size() < perPage) break;
            page++;
        }

        return allCommits;
    }

    public CommitValue getCommitId(String workspace, String repoSlug, String id) {
        String uri = baseUri + workspace + "/" + repoSlug + "/commit/" + id;
        ResponseEntity<CommitValue> response = authorizationService.getWithToken(uri, CommitValue.class);
        return response.getBody();
    }
}
