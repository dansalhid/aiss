package aiss.gitminer.controller;

import aiss.gitminer.model.Comment;
import aiss.gitminer.service.CommentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/gitminer/comments")
@Tag(name = "Comments", description = "Operaciones relacionadas con comentarios")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @Operation(summary = "Obtener todos los comentarios", description = "Devuelve una lista de todos los comentarios registrados")
    @ApiResponse(responseCode = "200", description = "Lista de comentarios",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Comment.class))))
    @GetMapping
    public ResponseEntity<List<Comment>> getAllComments() {
        List<Comment> comments = commentService.getAllComments();
        return ResponseEntity.ok(comments);
    }

    @Operation(summary = "Obtener un comentario por ID", description = "Devuelve el comentario asociado al ID dado")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Comentario encontrado",
                    content = @Content(schema = @Schema(implementation = Comment.class))),
            @ApiResponse(responseCode = "404", description = "Comentario no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Comment> getCommentById(@PathVariable Long id) {
        Comment comment = commentService.getCommentById(id);
        return comment != null ? ResponseEntity.ok(comment) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Actualizar un comentario", description = "Modifica un comentario existente identificado por su ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Comentario actualizado correctamente",
                    content = @Content(schema = @Schema(implementation = Comment.class))),
            @ApiResponse(responseCode = "404", description = "Comentario no encontrado")
    })
    @PutMapping("/{id}")
    public ResponseEntity<Comment> updateComment(@PathVariable Long id, @RequestBody Comment updatedComment) {
        Comment existingComment = commentService.getCommentById(id);
        if (existingComment == null) {
            return ResponseEntity.notFound().build();
        }

        updatedComment.setId(String.valueOf(id));
        Comment savedComment = commentService.updateComment(updatedComment);
        return ResponseEntity.ok(savedComment);
    }

    @Operation(summary = "Eliminar un comentario", description = "Elimina un comentario existente por su ID")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Comentario eliminado correctamente"),
            @ApiResponse(responseCode = "404", description = "Comentario no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Comment> deleteComment(@PathVariable Long id) {
        Comment comment = commentService.getCommentById(id);
        if (comment == null) {
            return ResponseEntity.notFound().build();
        }

        commentService.deleteComment(id);
        return ResponseEntity.noContent().build();
    }
}
