package aiss.bitbucketminer.authorizationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Service
public class AuthorizationService {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${bitbucketminer.token}")
    private String token;

    @Value("${bitbucketminer.username}")
    private String username;

    /**
     * Método para hacer una solicitud GET con autenticación utilizando el token.
     * @param uri URI a la que se realiza la solicitud.
     * @param c Tipo de clase a la que se debe mapear la respuesta.
     * @param <T> Tipo genérico para la respuesta.
     * @return ResponseEntity con la respuesta de la API.
     */
    public <T> ResponseEntity<T> getWithToken(String uri, Class<T> c) {
        if (token == null || token.isEmpty()) {
            throw new IllegalStateException("Token no configurado");
        }

        HttpHeaders headers = new HttpHeaders();
        // Añadir el token de autorización al encabezado
        String auth = username + ":" + token;
        byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(StandardCharsets.UTF_8));
        String authHeader = "Basic " + new String(encodedAuth);

        headers.set("Authorization", authHeader);



        HttpEntity<T> request = new HttpEntity<>(null, headers);

        // Realizar la solicitud GET con el encabezado y URI
        ResponseEntity<T> response = restTemplate.exchange(uri, HttpMethod.GET, request, c);
        return response;
    }
}
