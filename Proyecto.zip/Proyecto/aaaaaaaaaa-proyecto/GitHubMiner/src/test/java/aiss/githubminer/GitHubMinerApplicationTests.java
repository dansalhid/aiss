package aiss.githubminer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitHubMinerApplicationTests {

    @Test
    void contextLoads() {
    }

}
