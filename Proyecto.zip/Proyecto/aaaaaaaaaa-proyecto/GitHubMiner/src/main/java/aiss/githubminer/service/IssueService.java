package aiss.githubminer.service;

import aiss.githubminer.authorizationService.AuthorizationService;
import aiss.githubminer.model.Issue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class IssueService {

    @Autowired
    AuthorizationService authorizationService;

    @Value("${githubminer.baseUri}" + "repos/")
    private String baseUri;

    public List<Issue> getIssues(String owner, String repo, String sinceIssues, String maxPages) {
        List<Issue> allIssues = new ArrayList<>();
        String maxPagesClean = maxPages.trim();
        int pages = Integer.parseInt(maxPagesClean);

        ZonedDateTime dateTime = ZonedDateTime.now(ZoneOffset.UTC).minusDays(Integer.parseInt(sinceIssues));
        String since = dateTime.format(DateTimeFormatter.ISO_INSTANT);

        for (int i = 1; i <= pages; i++) {
            String uri = baseUri + owner + "/" + repo + "/issues?since=" + since + "&page=" + i + "&per_page=100";
            ResponseEntity<Issue[]> response = authorizationService.getWithToken(uri, Issue[].class);
            Issue[] issues = response.getBody();

            if (issues == null || issues.length == 0) {
                break;
            }

            allIssues.addAll(Arrays.asList(issues));

            if (issues.length < 100) {
                break;
            }
        }

        return allIssues;
    }

    public Issue getIssueByNumber(String owner, String repo, String number) {
        String uri = baseUri + owner + "/" + repo + "/issues/" + number;
        ResponseEntity<Issue> response = authorizationService.getWithToken(uri, Issue.class);
        return response.getBody();
    }
}
