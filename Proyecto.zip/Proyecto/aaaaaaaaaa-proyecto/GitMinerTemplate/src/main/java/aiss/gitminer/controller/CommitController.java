package aiss.gitminer.controller;

import aiss.gitminer.model.Commit;
import aiss.gitminer.service.CommitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/gitminer/commits")
@Tag(name = "Commits", description = "Operaciones relacionadas con commits")
public class CommitController {

    @Autowired
    private CommitService commitService;

    @Operation(summary = "Obtener todos los commits", description = "Devuelve una lista con todos los commits disponibles")
    @ApiResponse(responseCode = "200", description = "Lista de commits",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Commit.class))))
    @GetMapping
    public ResponseEntity<List<Commit>> getAllCommits() {
        List<Commit> commits = commitService.getAllCommits();
        return ResponseEntity.ok(commits);
    }

    @Operation(summary = "Obtener un commit por ID", description = "Devuelve un commit específico según su ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Commit encontrado",
                    content = @Content(schema = @Schema(implementation = Commit.class))),
            @ApiResponse(responseCode = "404", description = "Commit no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Commit> getCommitById(@PathVariable String id) {
        Commit commit = commitService.getCommitById(id);
        return commit != null ? ResponseEntity.ok(commit) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Actualizar un commit", description = "Modifica los datos de un commit existente identificado por su ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Commit actualizado correctamente",
                    content = @Content(schema = @Schema(implementation = Commit.class))),
            @ApiResponse(responseCode = "404", description = "Commit no encontrado")
    })
    @PutMapping("/{id}")
    public ResponseEntity<Commit> updateCommit(@PathVariable String id, @RequestBody Commit updatedCommit) {
        Commit existingCommit = commitService.getCommitById(id);
        if (existingCommit == null) {
            return ResponseEntity.notFound().build();
        }

        updatedCommit.setId(id);
        Commit savedCommit = commitService.updateCommit(updatedCommit);
        return ResponseEntity.ok(savedCommit);
    }

    @Operation(summary = "Eliminar un commit", description = "Elimina un commit existente por su ID")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Commit eliminado correctamente"),
            @ApiResponse(responseCode = "404", description = "Commit no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Commit> deleteCommit(@PathVariable String id) {
        Commit commit = commitService.getCommitById(id);
        if (commit == null) {
            return ResponseEntity.notFound().build();
        }
        commitService.deleteCommit(id);
        return ResponseEntity.noContent().build();
    }
}
