package aiss.gitminer.controller;

import aiss.gitminer.model.Comment;
import aiss.gitminer.model.Issue;
import aiss.gitminer.service.IssueService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/gitminer/issues")
@Tag(name = "Issues", description = "Operaciones relacionadas con incidencias")
public class IssueController {

    @Autowired
    private IssueService issueService;

    @Operation(summary = "Obtener todas las incidencias", description = "Devuelve una lista de todas las incidencias")
    @ApiResponse(responseCode = "200", description = "Lista de incidencias",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Issue.class))))
    @GetMapping
    public ResponseEntity<List<Issue>> getAllIssues() {
        List<Issue> issues = issueService.getAllIssues();
        return ResponseEntity.ok(issues);
    }

    @Operation(summary = "Obtener una incidencia por ID", description = "Devuelve la incidencia correspondiente al ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Incidencia encontrada",
                    content = @Content(schema = @Schema(implementation = Issue.class))),
            @ApiResponse(responseCode = "404", description = "Incidencia no encontrada")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Issue> getIssueById(@PathVariable String id) {
        Issue issue = issueService.getIssueById(id);
        return issue != null ? ResponseEntity.ok(issue) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Obtener incidencias por estado", description = "Filtra y devuelve incidencias según su estado (ej. OPEN, CLOSED)")
    @ApiResponse(responseCode = "200", description = "Incidencias filtradas por estado",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Issue.class))))
    @GetMapping("/state/{state}")
    public ResponseEntity<List<Issue>> getIssuesByState(@PathVariable String state) {
        List<Issue> issues = issueService.getIssuesByState(state);
        return ResponseEntity.ok(issues);
    }

    @Operation(summary = "Obtener comentarios de una incidencia", description = "Devuelve los comentarios asociados a una incidencia específica")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Comentarios encontrados",
                    content = @Content(array = @ArraySchema(schema = @Schema(implementation = Comment.class)))),
            @ApiResponse(responseCode = "404", description = "Incidencia no encontrada o sin comentarios")
    })
    @GetMapping("/{id}/comments")
    public ResponseEntity<List<Comment>> getCommentsFromIssue(@PathVariable String id) {
        List<Comment> comments = issueService.getCommentsFromIssue(id);
        return comments != null ? ResponseEntity.ok(comments) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Actualizar una incidencia", description = "Actualiza los datos de una incidencia existente por su ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Incidencia actualizada correctamente",
                    content = @Content(schema = @Schema(implementation = Issue.class))),
            @ApiResponse(responseCode = "404", description = "Incidencia no encontrada")
    })
    @PutMapping("/{id}")
    public ResponseEntity<Issue> updateIssue(@PathVariable String id, @RequestBody Issue updatedIssue) {
        Issue existingIssue = issueService.getIssueById(id);
        updatedIssue.setId(id);
        Issue savedIssue = issueService.updateIssue(updatedIssue);
        return existingIssue != null ? ResponseEntity.ok(savedIssue) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Eliminar una incidencia", description = "Elimina una incidencia existente por su ID")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Incidencia eliminada correctamente"),
            @ApiResponse(responseCode = "404", description = "Incidencia no encontrada")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Issue> deleteIssue(@PathVariable String id) {
        Issue existingIssue = issueService.getIssueById(id);
        issueService.deleteIssue(id);
        return existingIssue != null ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}